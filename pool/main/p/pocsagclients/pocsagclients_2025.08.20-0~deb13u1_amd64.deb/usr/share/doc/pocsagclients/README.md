The DAPNET Gateway links the MMDVM Host to the DAPNET network to receive paging messages.

The messages are buffered by the gateway when the host is busy with other modes, and then sends them to the host in order once the host becomes idle.

They build on 32-bit and 64-bit Linux as well as on Windows using Visual Studio 2017 on x86 and x64.

This software is licenced under the GPL v2 and is primarily intended for amateur and educational use.
