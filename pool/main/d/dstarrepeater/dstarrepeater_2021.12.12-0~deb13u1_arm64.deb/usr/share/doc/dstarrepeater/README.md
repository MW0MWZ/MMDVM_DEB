This is the D-Star Repeater which controls homebrew repeater hardware and links into the ircDDB Gateway to allow for access to extra non-RF facilities,

The hardware supported include:
* DVAP
* DV-Mega (D-Star only)
* GMSK Modems
* Soundcard repeaters (including UDRC)
* MMDVM (D-Star only)
* DV-RPTR V1, V2, and V3
* Icom Terminal and Access Point modes

They all build on 32-bit and 64-bit Linux as well as on Windows using Visual Studio 2017 on x86 and x64.

This software is licenced under the GPL v2.
