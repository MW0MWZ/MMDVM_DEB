The FM Gateway allows for use of different FM networking protocols from the MMDVM. Currently supported protocols are USRP, RAW (for SVX Link), IAX, and VAFM.

The Gateway has an ini file that contain the parameters for running the software. The filename of the ini file is passed as a parameter on the command line.

The MMDVM.ini file should have the IP address and port number of the gateway in the [FM Network] settings.

These programs build on 32-bit and 64-bit Linux as well as on Windows using Visual Studio 2022 on x86 and x64.

This software is licenced under the GPL v2 and is primarily intended for amateur and educational use.

For now, VAFM support is optional and requires the development libraries for Opus and libsamplerate to be installed.

To build the gateway with VAFM enabled, pass the VAFM flag to make:

`make VAFM=1`